<?php 
/**
 *  『萌芽模板网』多功能综合资源采集插件
 * 
 * 官方网站    www.vrecf.com
 * @author     萌芽<209910539@qq.com>
 * @version    v10.3.2
 * @time       2020.04.15
 * @说明	   请勿擅自修改文件内容，否则可能无法正常使用！
 */
header("Content-Type: text/html;charset=utf-8");
if(!@$_SERVER['HTTP_REFERER']||!$_COOKIE["admin_name"]) header('location:/');
$my = @require('../../application/extra/maccms.php');
$mac_ver = @require('../../application/extra/version.php'); 
$path = $my['site']['install_dir'];
if(!file_exists('create.php') || !file_exists('set_player.php') || !file_exists('close.php')){
	require('install.php');
    die;
}

?>